export const STUDIO_INFO = {
  name: "Studio de Beleza Grasi Neves",
  shortName: "Grazi Neves",
  slogan: "Pele macia, cuidado real em cada detalhe.",
  city: "Ariquemes – RO",
  neighborhood: "Rota do Sol",
  address: "Rua Centauro, 4778 – Rota do Sol, Ariquemes – RO, CEP 76874-040",
  phoneDisplay: "(69) 99217-5897",
  whatsappDigits: "5569992175897",
  whatsappDefaultMessage:
    "Olá! Conheci o trabalho de vocês pelo site e gostaria de saber mais sobre os serviços e agendar um horário.",
  mapsUrl:
    "https://www.google.com/maps/search/?api=1&query=Rua+Centauro%2C+4778%2C+Rota+do+Sol%2C+Ariquemes%2C+RO%2C+76874-040",
  instagramHandle: "@depiladora_grazi",
  instagramUrl: "https://www.instagram.com/depiladora_grazi/",
} as const;

export interface StudioPhoto {
  src: string;
  alt: string;
  caption: string;
}

export const STUDIO_IMAGES = {
  logo: {
    src: "/assets/aistudio/WhatsApp_Image_2026-11-16_at_22.45.13_9930c033.jpeg",
    alt: "Logotipo oficial Grasi Depiladora — Studio de Beleza Grasi Neves",
    caption: "Identidade oficial do Studio",
  },
  grazi: {
    src: "/assets/aistudio/WhatsApp_Image_2026-11-16_at_22.12.29_583a83f3.jpeg",
    alt: "Foto da Grazi sorrindo com luvas descartáveis pronta para o atendimento",
    caption: "Grazi — Atendimento acolhedor e cuidadoso",
  },
  reception: {
    src: "/assets/aistudio/WhatsApp_Image_2026-11-16_at_22.14.10_3463138e.jpeg",
    alt: "Recepção do Studio de Beleza Grasi Neves com espelho iluminado e sofá de espera",
    caption: "Recepção e área de espera",
  },
  treatmentRoom: {
    src: "/assets/aistudio/WhatsApp_Image_2026-11-16_at_22.13.07_b3ef82c6.jpeg",
    alt: "Sala de atendimento reservada com maca higienizada e conforto",
    caption: "Sala de atendimento reservada",
  },
  benefits: {
    src: "/assets/aistudio/WhatsApp_Image_2026-11-16_at_22.13.53_f2fede6b.jpeg",
    alt: "Benefícios da depilação com cera, Banho de Lua e esfoliação corporal",
    caption: "Depilação com cera, Banho de Lua e esfoliação",
  },
  feedback: {
    src: "/assets/aistudio/WhatsApp_Image_2026-11-16_at_22.13.32_85da6d16.jpeg",
    alt: "Avaliações e feedbacks reais de clientes atendidas no Studio",
    caption: "Feedbacks reais das nossas clientes",
  },
} as const satisfies Record<string, StudioPhoto>;

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  price?: string;
}

export const DEPILATION_SERVICES: ServiceItem[] = [
  { id: "perna-inteira", number: "01", title: "Perna inteira", price: "R$ 60,00" },
  { id: "meia-perna", number: "02", title: "Meia perna", price: "R$ 40,00" },
  { id: "virilha-completa", number: "03", title: "Virilha completa", price: "R$ 70,00" },
  { id: "nadegas", number: "04", title: "Nádegas", price: "R$ 30,00" },
  { id: "barriga-torax", number: "05", title: "Barriga + Tórax", price: "R$ 60,00" },
  { id: "costas", number: "06", title: "Costas", price: "R$ 50,00" },
  { id: "axila", number: "07", title: "Axila", price: "R$ 20,00" },
  { id: "extensao-braco", number: "08", title: "Extensão do braço", price: "R$ 50,00" },
  { id: "meio-braco", number: "09", title: "Meio braço", price: "R$ 35,00" },
  { id: "nariz", number: "10", title: "Nariz", price: "R$ 10,00" },
  { id: "rosto", number: "11", title: "Rosto", price: "R$ 40,00" },
];

export const BANHO_DE_LUA_SERVICE: ServiceItem = {
  id: "banho-de-lua",
  number: "12",
  title: "Banho de Lua",
};

export const ALL_SERVICES: ServiceItem[] = [
  ...DEPILATION_SERVICES,
  BANHO_DE_LUA_SERVICE,
];

export const BOOKING_PERIODS = [
  "Manhã",
  "Tarde",
  "Final da tarde",
  "A combinar",
] as const;

export type BookingPeriod = (typeof BOOKING_PERIODS)[number];

export function buildWhatsAppUrl(customMessage?: string): string {
  const text = encodeURIComponent(
    customMessage || STUDIO_INFO.whatsappDefaultMessage
  );
  return `https://wa.me/${STUDIO_INFO.whatsappDigits}?text=${text}`;
}
