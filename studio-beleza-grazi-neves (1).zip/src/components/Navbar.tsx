import { useState } from "react";
import { Check, Download, Loader2, Menu, MessageCircle, X } from "lucide-react";
import { buildWhatsAppUrl, STUDIO_IMAGES, STUDIO_INFO } from "../data/studio";

const NAV_LINKS = [
  { href: "#inicio", label: "Início" },
  { href: "#sobre-grazi", label: "Sobre" },
  { href: "#espaco", label: "Espaço" },
  { href: "#servicos", label: "Serviços" },
  { href: "#localizacao", label: "Localização" },
] as const;

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [downloadState, setDownloadState] = useState<"idle" | "loading" | "done">("idle");
  const whatsappHref = buildWhatsAppUrl();

  const handleDownloadZip = async () => {
    if (downloadState === "loading") return;
    setDownloadState("loading");
    try {
      const response = await fetch("/studio-beleza-grazi-neves.zip");
      if (!response.ok) {
        throw new Error("Falha ao baixar o ZIP");
      }
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = blobUrl;
      anchor.download = "studio-beleza-grazi-neves.zip";
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      URL.revokeObjectURL(blobUrl);
      setDownloadState("done");
      window.setTimeout(() => setDownloadState("idle"), 2500);
    } catch {
      setDownloadState("idle");
    }
  };

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-[hsl(var(--border))] bg-[hsl(var(--background)/0.92)] backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[1240px] items-center justify-between gap-2 px-3 sm:gap-4 sm:px-8 lg:gap-8 lg:px-10">
        {/* Zone 1: Logo + Grazi Neves + Clear ZIP Download Button */}
        <div className="flex items-center gap-2 whitespace-nowrap shrink-0">
          <a
            href="#inicio"
            className="flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[hsl(var(--accent))]"
          >
            <img
              src="/assets/logo-grasi-hd.png"
              alt={STUDIO_IMAGES.logo.alt}
              referrerPolicy="no-referrer"
              className="h-9 w-auto sm:h-11 object-contain"
            />
            <span className="font-display text-base font-semibold tracking-tight text-[hsl(var(--foreground))] sm:text-xl">
              {STUDIO_INFO.shortName}
            </span>
          </a>

          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={downloadState === "loading"}
            title="Baixar projeto completo em ZIP para subir no GitHub"
            aria-label="Baixar arquivo ZIP do projeto para GitHub"
            className="inline-flex h-9 items-center gap-1.5 rounded-full border border-[hsl(var(--accent))] bg-[hsl(var(--accent)/0.22)] px-2.5 text-xs font-semibold text-[hsl(var(--foreground))] transition-colors duration-200 hover:bg-[hsl(var(--accent))] hover:text-[hsl(var(--accent-ink))] disabled:opacity-60 cursor-pointer shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--accent))]"
          >
            {downloadState === "loading" ? (
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            ) : downloadState === "done" ? (
              <Check className="h-4 w-4" aria-hidden="true" />
            ) : (
              <Download className="h-4 w-4" aria-hidden="true" />
            )}
            <span className="hidden sm:inline">
              {downloadState === "done" ? "Baixado" : "ZIP"}
            </span>
          </button>
        </div>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav
          aria-label="Navegação principal"
          className="hidden items-center gap-6 md:flex lg:gap-7"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative py-1 text-sm font-medium text-[hsl(var(--foreground-muted))] transition-colors duration-200 hover:text-[hsl(var(--foreground))] whitespace-nowrap shrink-0 after:absolute after:inset-x-0 after:bottom-0 after:h-0.5 after:origin-left after:scale-x-0 after:bg-[hsl(var(--accent))] after:transition-transform after:duration-200 hover:after:scale-x-100 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[hsl(var(--accent))]"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center gap-2 shrink-0">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-10 items-center gap-2 rounded-full bg-[hsl(var(--accent))] px-4 py-2 text-xs font-semibold text-[hsl(var(--accent-ink))] transition-colors duration-200 hover:bg-[hsl(var(--accent-hover))] whitespace-nowrap shrink-0 sm:px-5 sm:text-sm focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--foreground))]"
          >
            <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span className="hidden sm:inline">Agendar no WhatsApp</span>
            <span className="sm:hidden">WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-controls="mobile-navigation"
            aria-label={mobileOpen ? "Fechar menu" : "Abrir menu"}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[hsl(var(--border))] text-[hsl(var(--foreground))] transition-colors hover:border-[hsl(var(--accent))] md:hidden focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--accent))]"
          >
            {mobileOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <nav
          id="mobile-navigation"
          aria-label="Navegação mobile"
          className="border-t border-[hsl(var(--border))] bg-[hsl(var(--background)/0.98)] px-5 py-4 backdrop-blur-md md:hidden"
        >
          <ul className="flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="flex min-h-11 items-center text-sm font-medium text-[hsl(var(--foreground))] transition-colors hover:text-[hsl(var(--accent-text))]"
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="#contato"
                onClick={() => setMobileOpen(false)}
                className="flex min-h-11 items-center text-sm font-semibold text-[hsl(var(--accent-text))]"
              >
                Contato e Agendamento
              </a>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
