import {
  ArrowUpRight,
  Instagram,
  MapPin,
  MessageCircle,
  Phone,
} from "lucide-react";
import { buildWhatsAppUrl, STUDIO_IMAGES, STUDIO_INFO } from "../data/studio";

export function ContactFooter() {
  const whatsappHref = buildWhatsAppUrl();

  return (
    <>
      <section
        id="contato"
        className="border-t border-[hsl(var(--border))] bg-[hsl(var(--surface-rose-soft))] py-16 sm:py-20"
      >
        <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
          <div className="mx-auto grid max-w-4xl grid-cols-1 gap-8 rounded-3xl border border-[hsl(var(--border-strong))] bg-[hsl(var(--surface-elevated))] p-6 shadow-sm sm:p-10 md:grid-cols-12">
            <div className="space-y-4 md:col-span-6">
              <p className="text-xs font-semibold tracking-[0.14em] text-[hsl(var(--accent-text))] uppercase">
                Contato Direto
              </p>
              <h2 className="font-display text-[clamp(1.75rem,3vw,2.35rem)] leading-tight font-semibold tracking-tight text-[hsl(var(--foreground))]">
                Fale com o Studio de Beleza Grasi Neves
              </h2>
              <p className="text-sm leading-relaxed text-[hsl(var(--foreground-muted))]">
                Estamos à disposição pelo WhatsApp e Instagram para tirar suas
                dúvidas e agendar o seu horário.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 items-center gap-2 rounded-full bg-[hsl(var(--accent))] px-6 py-2.5 text-sm font-semibold text-[hsl(var(--accent-ink))] transition-colors hover:bg-[hsl(var(--accent-hover))] whitespace-nowrap"
                >
                  <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Conversar no WhatsApp</span>
                </a>

                <a
                  href={STUDIO_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 items-center gap-2 rounded-full border border-[hsl(var(--border-strong))] bg-[hsl(var(--background))] px-5 py-2.5 text-sm font-semibold text-[hsl(var(--foreground))] transition-colors hover:border-[hsl(var(--accent))] whitespace-nowrap"
                >
                  <Instagram className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>{STUDIO_INFO.instagramHandle}</span>
                </a>
              </div>
            </div>

            <div className="divide-y divide-[hsl(var(--border))] border-t border-[hsl(var(--border))] md:col-span-6 md:border-t-0 md:border-l md:pl-8">
              <div className="flex items-start gap-3 py-4 first:pt-0">
                <Phone
                  className="mt-0.5 h-4 w-4 shrink-0 text-[hsl(var(--accent-text))]"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs font-semibold tracking-wider text-[hsl(var(--foreground-muted))] uppercase">
                    WhatsApp
                  </p>
                  <a
                    href={whatsappHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm font-semibold text-[hsl(var(--foreground))] tabular-nums hover:text-[hsl(var(--accent-text))]"
                  >
                    {STUDIO_INFO.phoneDisplay}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 py-4">
                <Instagram
                  className="mt-0.5 h-4 w-4 shrink-0 text-[hsl(var(--accent-text))]"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs font-semibold tracking-wider text-[hsl(var(--foreground-muted))] uppercase">
                    Instagram
                  </p>
                  <a
                    href={STUDIO_INFO.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-sm font-semibold text-[hsl(var(--foreground))] hover:text-[hsl(var(--accent-text))]"
                  >
                    <span>{STUDIO_INFO.instagramHandle}</span>
                    <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 py-4 last:pb-0">
                <MapPin
                  className="mt-0.5 h-4 w-4 shrink-0 text-[hsl(var(--accent-text))]"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs font-semibold tracking-wider text-[hsl(var(--foreground-muted))] uppercase">
                    Endereço
                  </p>
                  <a
                    href={STUDIO_INFO.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs leading-relaxed text-[hsl(var(--foreground))] hover:text-[hsl(var(--accent-text))] sm:text-sm"
                  >
                    {STUDIO_INFO.address}
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Rosé Nude & Ice White Footer */}
      <footer className="border-t border-[hsl(var(--border-strong))] bg-[hsl(var(--surface))] py-10 pb-28 text-[hsl(var(--foreground))] sm:py-12">
        <div className="mx-auto flex max-w-[1240px] flex-col justify-between gap-6 px-5 sm:px-8 lg:flex-row lg:items-center lg:px-10">
          <div className="flex items-center gap-3">
            <img
              src={STUDIO_IMAGES.logo.src}
              alt={STUDIO_IMAGES.logo.alt}
              referrerPolicy="no-referrer"
              className="h-10 w-28 rounded-lg border border-[hsl(var(--border-strong))] bg-[hsl(var(--surface-elevated))] px-2 py-1 object-contain"
            />
            <div>
              <p className="font-display text-base font-semibold text-[hsl(var(--foreground))]">
                {STUDIO_INFO.name}
              </p>
              <p className="text-xs text-[hsl(var(--foreground-muted))]">
                {STUDIO_INFO.address}
              </p>
            </div>
          </div>

          <nav
            aria-label="Links do rodapé"
            className="flex flex-wrap items-center gap-5 text-xs font-medium text-[hsl(var(--foreground-muted))]"
          >
            <a href="#inicio" className="hover:text-[hsl(var(--foreground))]">
              Início
            </a>
            <a href="#sobre-grazi" className="hover:text-[hsl(var(--foreground))]">
              Sobre
            </a>
            <a href="#espaco" className="hover:text-[hsl(var(--foreground))]">
              Espaço
            </a>
            <a href="#servicos" className="hover:text-[hsl(var(--foreground))]">
              Serviços
            </a>
            <a href="#localizacao" className="hover:text-[hsl(var(--foreground))]">
              Localização
            </a>
            <a
              href={STUDIO_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 font-semibold text-[hsl(var(--accent-text))] hover:underline"
            >
              <Instagram className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
              <span>{STUDIO_INFO.instagramHandle}</span>
            </a>
          </nav>

          <p className="text-xs text-[hsl(var(--foreground-muted))]">
            © {new Date().getFullYear()} {STUDIO_INFO.name}
          </p>
        </div>
      </footer>
    </>
  );
}
