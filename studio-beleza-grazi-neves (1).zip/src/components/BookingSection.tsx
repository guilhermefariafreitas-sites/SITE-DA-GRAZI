import { FormEvent, useRef, useState } from "react";
import { Check, MessageCircle } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import {
  ALL_SERVICES,
  BOOKING_PERIODS,
  BookingPeriod,
  buildWhatsAppUrl,
} from "../data/studio";

interface BookingSectionProps {
  selectedServiceId: string;
  onSelectService: (serviceId: string) => void;
}

export function BookingSection({
  selectedServiceId,
  onSelectService,
}: BookingSectionProps) {
  const [period, setPeriod] = useState<BookingPeriod>("Tarde");
  const [clientName, setClientName] = useState("");
  const [notes, setNotes] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const nameInputRef = useRef<HTMLInputElement>(null);
  const prefersReducedMotion = useReducedMotion();

  const selectedService =
    ALL_SERVICES.find((s) => s.id === selectedServiceId) ?? ALL_SERVICES[0];

  const trimmedName = clientName.trim();
  const isNameValid = trimmedName.length >= 2;

  const formattedMessage = [
    `Olá! Me chamo ${trimmedName || "cliente"}. Conheci o trabalho de vocês pelo site e gostaria de agendar: ${selectedService.title}${selectedService.price ? ` (${selectedService.price})` : ""}.`,
    `Período de preferência: ${period}.`,
    notes.trim() ? `Observação: ${notes.trim()}.` : "",
  ]
    .filter(Boolean)
    .join(" ");

  const whatsappUrl = buildWhatsAppUrl(formattedMessage);

  const handleInvalidSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!isNameValid) {
      setErrorMessage(
        "Por favor, informe seu nome para personalizar o atendimento."
      );
      nameInputRef.current?.focus();
      return;
    }
    setErrorMessage("");
    setSubmitted(true);
  };

  return (
    <section
      id="agendamento"
      className="border-t border-[hsl(var(--border))] bg-[hsl(var(--background))] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{
            duration: prefersReducedMotion ? 0 : 0.5,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="mx-auto max-w-4xl"
        >
          <div className="mb-10 space-y-3 text-center">
            <p className="text-xs font-semibold tracking-[0.14em] text-[hsl(var(--accent-text))] uppercase">
              Agendamento Online
            </p>
            <h2 className="font-display text-[clamp(1.75rem,3.2vw,2.65rem)] leading-tight font-semibold tracking-tight text-[hsl(var(--foreground))]">
              Reserve seu horário pelo WhatsApp
            </h2>
            <p className="mx-auto max-w-md text-sm leading-relaxed text-[hsl(var(--foreground-muted))] sm:text-base">
              Escolha o procedimento desejado e envie sua solicitação direto
              para a Grazi.
            </p>
          </div>

          <form
            onSubmit={handleInvalidSubmit}
            noValidate
            className="space-y-8 rounded-3xl border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] p-6 shadow-sm sm:p-10"
          >
            {/* Step 1: Service Selection */}
            <fieldset className="space-y-3">
              <legend className="text-xs font-semibold tracking-wider text-[hsl(var(--foreground-muted))] uppercase">
                1. Escolha o serviço
              </legend>
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
                {ALL_SERVICES.map((service) => {
                  const isSelected = service.id === selectedService.id;
                  return (
                    <button
                      key={service.id}
                      type="button"
                      aria-pressed={isSelected}
                      onClick={() => {
                        onSelectService(service.id);
                        setSubmitted(false);
                      }}
                      className={`flex min-h-11 items-center justify-between gap-2 rounded-xl border px-3.5 py-2.5 text-left text-xs transition-colors duration-200 sm:text-sm focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--accent))] ${
                        isSelected
                          ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent)/0.25)] font-semibold text-[hsl(var(--foreground))]"
                          : "border-[hsl(var(--border))] bg-[hsl(var(--background))] text-[hsl(var(--foreground-muted))] hover:border-[hsl(var(--accent))] hover:text-[hsl(var(--foreground))]"
                      }`}
                    >
                      <span className="truncate">{service.title}</span>
                      <span className="flex items-center gap-1.5 shrink-0">
                        {service.price && (
                          <span className="text-xs font-semibold text-[hsl(var(--foreground))] tabular-nums">
                            {service.price}
                          </span>
                        )}
                        {isSelected && (
                          <Check
                            className="h-4 w-4 shrink-0 text-[hsl(var(--accent-text))]"
                            aria-hidden="true"
                          />
                        )}
                      </span>
                    </button>
                  );
                })}
              </div>
            </fieldset>

            {/* Step 2: Preferred Period */}
            <fieldset className="space-y-3">
              <legend className="text-xs font-semibold tracking-wider text-[hsl(var(--foreground-muted))] uppercase">
                2. Período preferido
              </legend>
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                {BOOKING_PERIODS.map((option) => {
                  const isSelected = period === option;
                  return (
                    <button
                      key={option}
                      type="button"
                      aria-pressed={isSelected}
                      onClick={() => {
                        setPeriod(option);
                        setSubmitted(false);
                      }}
                      className={`min-h-11 rounded-full border px-4 py-2 text-xs font-semibold transition-colors duration-200 whitespace-nowrap sm:text-sm focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--accent))] ${
                        isSelected
                          ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent))] text-[hsl(var(--accent-ink))]"
                          : "border-[hsl(var(--border))] bg-[hsl(var(--background))] text-[hsl(var(--foreground-muted))] hover:border-[hsl(var(--accent))] hover:text-[hsl(var(--foreground))]"
                      }`}
                    >
                      {option}
                    </button>
                  );
                })}
              </div>
            </fieldset>

            {/* Step 3: Name & Optional Notes */}
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <div className="space-y-2">
                <label
                  htmlFor="booking-name"
                  className="block text-xs font-semibold tracking-wider text-[hsl(var(--foreground-muted))] uppercase"
                >
                  Seu nome
                </label>
                <input
                  ref={nameInputRef}
                  id="booking-name"
                  name="clientName"
                  type="text"
                  autoComplete="name"
                  required
                  value={clientName}
                  onChange={(e) => {
                    setClientName(e.target.value);
                    if (errorMessage && e.target.value.trim().length >= 2) {
                      setErrorMessage("");
                    }
                    setSubmitted(false);
                  }}
                  placeholder="Ex.: Mariana Souza"
                  aria-invalid={Boolean(errorMessage)}
                  aria-describedby={
                    errorMessage ? "booking-name-error" : undefined
                  }
                  className="min-h-12 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] px-4 py-3 text-sm text-[hsl(var(--foreground))] placeholder:text-[hsl(var(--foreground-muted)/0.65)] transition-colors focus:border-[hsl(var(--accent))] focus:outline-none"
                />
                {errorMessage && (
                  <p
                    id="booking-name-error"
                    role="alert"
                    className="text-xs font-semibold text-[hsl(var(--accent-text))]"
                  >
                    {errorMessage}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label
                  htmlFor="booking-notes"
                  className="block text-xs font-semibold tracking-wider text-[hsl(var(--foreground-muted))] uppercase"
                >
                  Dia ou observação (opcional)
                </label>
                <input
                  id="booking-notes"
                  name="notes"
                  type="text"
                  value={notes}
                  onChange={(e) => {
                    setNotes(e.target.value);
                    setSubmitted(false);
                  }}
                  placeholder="Ex.: Sexta-feira ou pele sensível"
                  className="min-h-12 w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] px-4 py-3 text-sm text-[hsl(var(--foreground))] placeholder:text-[hsl(var(--foreground-muted)/0.65)] transition-colors focus:border-[hsl(var(--accent))] focus:outline-none"
                />
              </div>
            </div>

            {/* Submit / Direct WhatsApp Action */}
            <div className="flex flex-col items-start justify-between gap-4 border-t border-[hsl(var(--border))] pt-6 sm:flex-row sm:items-center">
              <p className="text-xs leading-relaxed text-[hsl(var(--foreground-muted))]">
                Você confirmará o horário diretamente com a Grazi pelo WhatsApp.
              </p>

              {isNameValid ? (
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => {
                    setErrorMessage("");
                    setSubmitted(true);
                  }}
                  className="inline-flex min-h-12 w-full items-center justify-center gap-2.5 rounded-full bg-[hsl(var(--accent))] px-7 py-3.5 text-sm font-semibold text-[hsl(var(--accent-ink))] transition-all duration-200 hover:-translate-y-0.5 hover:bg-[hsl(var(--accent-hover))] whitespace-nowrap sm:w-auto focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--foreground))]"
                >
                  <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Enviar pelo WhatsApp</span>
                </a>
              ) : (
                <button
                  type="submit"
                  className="inline-flex min-h-12 w-full items-center justify-center gap-2.5 rounded-full bg-[hsl(var(--accent))] px-7 py-3.5 text-sm font-semibold text-[hsl(var(--accent-ink))] transition-all duration-200 hover:-translate-y-0.5 hover:bg-[hsl(var(--accent-hover))] whitespace-nowrap sm:w-auto focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--foreground))]"
                >
                  <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Enviar pelo WhatsApp</span>
                </button>
              )}
            </div>

            {submitted && isNameValid && (
              <div
                role="status"
                className="flex flex-col justify-between gap-3 rounded-xl border border-[hsl(var(--accent))] bg-[hsl(var(--accent)/0.16)] px-5 py-4 text-sm text-[hsl(var(--foreground))] sm:flex-row sm:items-center"
              >
                <span>
                  Sua mensagem foi preparada para{" "}
                  <strong>{selectedService.title}</strong>
                  {selectedService.price ? ` (${selectedService.price})` : ""}.
                </span>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold text-[hsl(var(--accent-text))] underline underline-offset-4 whitespace-nowrap"
                >
                  Abrir WhatsApp novamente
                </a>
              </div>
            )}
          </form>
        </motion.div>
      </div>
    </section>
  );
}
