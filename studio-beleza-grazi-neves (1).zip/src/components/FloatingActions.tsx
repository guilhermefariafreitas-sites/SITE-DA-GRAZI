import { MapPin } from "lucide-react";
import { buildWhatsAppUrl, STUDIO_INFO } from "../data/studio";

export function FloatingActions() {
  const whatsappHref = buildWhatsAppUrl();

  return (
    <div
      aria-label="Ações rápidas de contato e localização"
      className="fixed right-4 bottom-4 z-40 flex flex-col items-end gap-3 sm:right-6 sm:bottom-6"
    >
      {/* Google Maps Floating Button */}
      <a
        href={STUDIO_INFO.mapsUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Abrir localização do estúdio no Google Maps"
        title="Como chegar no Google Maps"
        className="group relative flex h-12 w-12 items-center justify-center rounded-full border border-[hsl(var(--border-strong))] bg-[hsl(var(--surface-elevated)/0.95)] text-[hsl(var(--foreground))] shadow-md backdrop-blur-md transition-all duration-200 hover:-translate-y-0.5 hover:border-[hsl(var(--accent))] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--accent))]"
      >
        <MapPin className="h-5 w-5" strokeWidth={1.8} aria-hidden="true" />
        <span className="pointer-events-none absolute right-14 hidden rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] px-3 py-1.5 text-xs font-semibold text-[hsl(var(--foreground))] opacity-0 shadow-sm transition-opacity duration-200 whitespace-nowrap group-hover:opacity-100 sm:block">
          Como chegar
        </span>
      </a>

      {/* WhatsApp Floating Button */}
      <a
        href={whatsappHref}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Conversar no WhatsApp com o Studio de Beleza Grasi Neves"
        title="Conversar no WhatsApp"
        className="group relative flex h-12 w-12 items-center justify-center rounded-full border border-[hsl(var(--border-strong))] bg-[hsl(var(--accent))] text-[hsl(var(--accent-ink))] shadow-md transition-all duration-200 hover:-translate-y-0.5 hover:bg-[hsl(var(--accent-hover))] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--foreground))]"
      >
        <svg
          viewBox="0 0 24 24"
          className="h-5 w-5 fill-current"
          aria-hidden="true"
        >
          <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91C21.95 6.45 17.5 2 12.04 2zm5.79 14.12c-.24.68-1.41 1.3-1.95 1.38-.5.08-1.13.11-1.82-.11-.42-.14-.96-.32-1.65-.62-2.9-1.25-4.79-4.18-4.93-4.37-.14-.19-1.18-1.57-1.18-3 0-1.43.75-2.13 1.01-2.42.26-.29.58-.36.77-.36.19 0 .39 0 .56.01.18.01.42-.07.66.5.24.58.82 2.01.89 2.16.07.15.12.32.02.51-.1.19-.15.32-.3.49-.15.17-.31.38-.44.51-.15.15-.3.31-.13.61.17.29.76 1.26 1.64 2.04 1.13 1 2.08 1.31 2.38 1.46.3.15.47.12.64-.07.17-.19.74-.86.94-1.15.19-.29.39-.24.66-.14.27.1 1.71.81 2 .96.3.15.5.22.57.34.07.12.07.7-.17 1.38z" />
        </svg>
        <span className="pointer-events-none absolute right-14 hidden rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] px-3 py-1.5 text-xs font-semibold text-[hsl(var(--foreground))] opacity-0 shadow-sm transition-opacity duration-200 whitespace-nowrap group-hover:opacity-100 sm:block">
          WhatsApp
        </span>
      </a>
    </div>
  );
}
