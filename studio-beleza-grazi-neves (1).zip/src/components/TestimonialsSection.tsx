import { ArrowUpRight, Instagram } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import { STUDIO_IMAGES, STUDIO_INFO, StudioPhoto } from "../data/studio";
import { EditorialImage } from "./EditorialImage";

interface TestimonialsSectionProps {
  onZoomPhoto: (photo: StudioPhoto) => void;
}

export function TestimonialsSection({ onZoomPhoto }: TestimonialsSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="depoimentos"
      className="border-t border-[hsl(var(--border))] bg-[hsl(var(--background))] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{
            duration: prefersReducedMotion ? 0 : 0.5,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="mb-10 max-w-xl space-y-3"
        >
          <p className="text-xs font-semibold tracking-[0.14em] text-[hsl(var(--accent-text))] uppercase">
            Experiências Reais
          </p>
          <h2 className="font-display text-[clamp(1.75rem,3.2vw,2.65rem)] leading-tight font-semibold tracking-tight text-[hsl(var(--foreground))]">
            O Que Nossas Clientes Dizem
          </h2>
          <p className="text-sm leading-relaxed text-[hsl(var(--foreground-muted))] sm:text-base">
            Registros reais de quem já viveu a experiência de cuidado no estúdio.
            Clique na imagem para ampliar e ler os depoimentos completos.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 items-center gap-8 md:grid-cols-12">
          {/* Real Uploaded Feedback Photo */}
          <div className="flex justify-center md:col-span-5">
            <figure className="w-full max-w-xs space-y-2.5 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] p-3 shadow-sm">
              <EditorialImage
                src={STUDIO_IMAGES.feedback.src}
                alt={STUDIO_IMAGES.feedback.alt}
                onZoom={() => onZoomPhoto(STUDIO_IMAGES.feedback)}
                className="aspect-[3/4] w-full rounded-xl"
              />
              <figcaption className="text-center text-xs font-medium text-[hsl(var(--foreground-muted))]">
                {STUDIO_IMAGES.feedback.caption}
              </figcaption>
            </figure>
          </div>

          {/* Dedicated Space for Future Real Feedback Photos & Instagram Link */}
          <div className="space-y-5 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--surface))] p-6 sm:p-8 md:col-span-7">
            <h3 className="font-display text-xl font-semibold text-[hsl(var(--foreground))]">
              Mais avaliações e feedbacks reais
            </h3>
            <p className="text-sm leading-relaxed text-[hsl(var(--foreground-muted))]">
              Compartilhamos frequentemente fotos e relatos reais enviados por
              nossas clientes em nosso perfil oficial no Instagram.
            </p>

            <div className="rounded-xl border border-dashed border-[hsl(var(--border-strong))] bg-[hsl(var(--background))] px-5 py-4 text-xs text-[hsl(var(--foreground-muted))]">
              Espaço reservado para novas capturas e fotos de feedbacks reais das
              clientes atendidas.
            </div>

            <a
              href={STUDIO_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-11 items-center gap-2 rounded-full bg-[hsl(var(--accent))] px-5 py-2.5 text-xs font-semibold text-[hsl(var(--accent-ink))] transition-colors hover:bg-[hsl(var(--accent-hover))] whitespace-nowrap"
            >
              <Instagram className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>Ver feedbacks no {STUDIO_INFO.instagramHandle}</span>
              <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
