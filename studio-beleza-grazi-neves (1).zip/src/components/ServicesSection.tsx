import { ArrowUpRight } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import { DEPILATION_SERVICES } from "../data/studio";

interface ServicesSectionProps {
  onSelectService: (serviceId: string) => void;
}

export function ServicesSection({ onSelectService }: ServicesSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  const handleBookClick = (serviceId: string) => {
    onSelectService(serviceId);
    const target = document.getElementById("agendamento");
    if (target) {
      target.scrollIntoView({
        behavior: prefersReducedMotion ? "auto" : "smooth",
      });
    }
  };

  return (
    <section
      id="servicos"
      className="border-t border-[hsl(var(--border))] bg-[hsl(var(--background))] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{
            duration: prefersReducedMotion ? 0 : 0.5,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="mb-12 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"
        >
          <div className="max-w-xl space-y-3">
            <h2 className="font-display text-[clamp(1.75rem,3.2vw,2.65rem)] leading-tight font-semibold tracking-tight text-[hsl(var(--foreground))]">
              Depilação
            </h2>
            <p className="text-sm leading-relaxed text-[hsl(var(--foreground-muted))] sm:text-base">
              Confira os procedimentos de depilação com cera e escolha o ideal
              para o seu atendimento.
            </p>
          </div>
          <p className="text-xs font-medium text-[hsl(var(--foreground-muted))] tabular-nums">
            11 procedimentos · Valores individuais
          </p>
        </motion.div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {DEPILATION_SERVICES.map((service, index) => (
            <motion.div
              key={service.id}
              initial={prefersReducedMotion ? false : { opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.1 }}
              transition={{
                duration: prefersReducedMotion ? 0 : 0.45,
                delay: prefersReducedMotion ? 0 : index * 0.03,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="flex flex-col justify-between gap-4 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] p-5 shadow-sm transition-colors duration-200 hover:border-[hsl(var(--accent))]"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <span className="text-xs font-semibold text-[hsl(var(--accent-text))] tabular-nums">
                    {service.number}
                  </span>
                  <h3 className="font-display text-lg font-semibold text-[hsl(var(--foreground))]">
                    {service.title}
                  </h3>
                </div>

                {service.price && (
                  <span className="rounded-full bg-[hsl(var(--accent)/0.25)] px-3.5 py-1.5 text-sm font-bold text-[hsl(var(--foreground))] tabular-nums whitespace-nowrap shrink-0">
                    {service.price}
                  </span>
                )}
              </div>

              <div className="flex items-center justify-between border-t border-[hsl(var(--border))] pt-3.5">
                <span className="text-xs text-[hsl(var(--foreground-muted))]">
                  Depilação com cera
                </span>
                <button
                  type="button"
                  onClick={() => handleBookClick(service.id)}
                  aria-label={`Agendar ${service.title}`}
                  className="inline-flex min-h-9 items-center gap-1 rounded-full border border-[hsl(var(--border-strong))] bg-[hsl(var(--background))] px-3.5 py-1.5 text-xs font-semibold text-[hsl(var(--foreground))] transition-colors duration-200 hover:border-[hsl(var(--accent))] hover:bg-[hsl(var(--accent))] hover:text-[hsl(var(--accent-ink))] whitespace-nowrap"
                >
                  <span>Agendar</span>
                  <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
