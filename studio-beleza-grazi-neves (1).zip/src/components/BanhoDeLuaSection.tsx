import { ArrowUpRight, MessageCircle, Sparkles } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import {
  BANHO_DE_LUA_SERVICE,
  buildWhatsAppUrl,
  STUDIO_IMAGES,
  StudioPhoto,
} from "../data/studio";
import { EditorialImage } from "./EditorialImage";

interface BanhoDeLuaSectionProps {
  onSelectService: (serviceId: string) => void;
  onZoomPhoto: (photo: StudioPhoto) => void;
}

export function BanhoDeLuaSection({
  onSelectService,
  onZoomPhoto,
}: BanhoDeLuaSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  const handleBookClick = () => {
    onSelectService(BANHO_DE_LUA_SERVICE.id);
    const target = document.getElementById("agendamento");
    if (target) {
      target.scrollIntoView({
        behavior: prefersReducedMotion ? "auto" : "smooth",
      });
    }
  };

  return (
    <section
      id="banho-de-lua"
      className="border-t border-[hsl(var(--border))] bg-[hsl(var(--surface-rose-soft))] py-16 sm:py-20"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{
            duration: prefersReducedMotion ? 0 : 0.5,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="mx-auto grid max-w-4xl grid-cols-1 items-center gap-8 rounded-3xl border border-[hsl(var(--border-strong))] bg-[hsl(var(--surface-elevated))] p-6 shadow-sm sm:p-10 md:grid-cols-12"
        >
          <div className="space-y-5 md:col-span-7">
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-[0.14em] text-[hsl(var(--accent-text))] uppercase">
              <Sparkles className="h-4 w-4" aria-hidden="true" />
              <span>Cuidado Especial</span>
            </div>

            <h2 className="font-display text-[clamp(1.75rem,3vw,2.5rem)] leading-tight font-semibold tracking-tight text-[hsl(var(--foreground))]">
              Banho de Lua
            </h2>

            <p className="text-sm leading-relaxed text-[hsl(var(--foreground-muted))] sm:text-base">
              Um momento dedicado à beleza e uniformidade da pele, promovendo
              renovação, remoção de células mortas e hidratação profunda para um
              toque macio e luminoso.
            </p>

            <ul className="space-y-2 border-t border-[hsl(var(--border))] pt-4 text-sm text-[hsl(var(--foreground))]">
              <li>· Melhora a textura da pele</li>
              <li>· Remove células mortas com suavidade</li>
              <li>· Hidratação profunda e toque aveludado</li>
            </ul>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href={buildWhatsAppUrl(
                  "Olá! Gostaria de saber mais sobre o serviço Banho de Lua e consultar valores e horários."
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-11 items-center gap-2 rounded-full bg-[hsl(var(--accent))] px-5 py-2.5 text-xs font-semibold text-[hsl(var(--accent-ink))] transition-colors hover:bg-[hsl(var(--accent-hover))] whitespace-nowrap"
              >
                <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Consultar no WhatsApp</span>
              </a>

              <button
                type="button"
                onClick={handleBookClick}
                className="inline-flex min-h-11 items-center gap-1.5 rounded-full border border-[hsl(var(--border-strong))] bg-[hsl(var(--background))] px-5 py-2.5 text-xs font-semibold text-[hsl(var(--foreground))] transition-colors hover:border-[hsl(var(--accent))] whitespace-nowrap"
              >
                <span>Agendar Banho de Lua</span>
                <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            </div>
          </div>

          <div className="flex justify-center md:col-span-5">
            <div className="w-full max-w-[250px] overflow-hidden rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--surface))] p-2">
              <EditorialImage
                src={STUDIO_IMAGES.benefits.src}
                alt={STUDIO_IMAGES.benefits.alt}
                onZoom={() => onZoomPhoto(STUDIO_IMAGES.benefits)}
                className="aspect-[3/4] w-full rounded-xl"
              />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
