import { motion, useReducedMotion } from "motion/react";
import { STUDIO_IMAGES, StudioPhoto } from "../data/studio";
import { EditorialImage } from "./EditorialImage";

interface StudioSpaceSectionProps {
  onZoomPhoto: (photo: StudioPhoto) => void;
}

const SPACE_PHOTOS = [
  STUDIO_IMAGES.reception,
  STUDIO_IMAGES.treatmentRoom,
  STUDIO_IMAGES.benefits,
] as const;

export function StudioSpaceSection({ onZoomPhoto }: StudioSpaceSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="espaco"
      className="border-t border-[hsl(var(--border))] bg-[hsl(var(--surface))] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{
            duration: prefersReducedMotion ? 0 : 0.5,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="mb-10 max-w-xl space-y-3"
        >
          <p className="text-xs font-semibold tracking-[0.14em] text-[hsl(var(--accent-text))] uppercase">
            Nosso Ambiente
          </p>
          <h2 className="font-display text-[clamp(1.75rem,3.2vw,2.65rem)] leading-tight font-semibold tracking-tight text-[hsl(var(--foreground))]">
            Conheça Nosso Espaço
          </h2>
          <p className="text-sm leading-relaxed text-[hsl(var(--foreground-muted))] sm:text-base">
            Clique em qualquer foto para ampliar e conhecer o conforto e o
            preparo do nosso estúdio.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SPACE_PHOTOS.map((photo, index) => (
            <motion.figure
              key={photo.src}
              initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{
                duration: prefersReducedMotion ? 0 : 0.5,
                delay: prefersReducedMotion ? 0 : index * 0.05,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="mx-auto w-full max-w-sm space-y-3 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] p-3 shadow-sm"
            >
              <EditorialImage
                src={photo.src}
                alt={photo.alt}
                onZoom={() => onZoomPhoto(photo)}
                className="aspect-[4/3] w-full rounded-xl"
                imgClassName="transition-transform duration-300 group-hover:scale-[1.03]"
              />
              <figcaption className="px-1 pb-1 text-center text-xs font-medium text-[hsl(var(--foreground-muted))] sm:text-sm">
                {photo.caption}
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
