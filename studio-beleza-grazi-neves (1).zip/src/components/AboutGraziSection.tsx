import { Instagram, MessageCircle } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import {
  buildWhatsAppUrl,
  STUDIO_IMAGES,
  STUDIO_INFO,
  StudioPhoto,
} from "../data/studio";
import { EditorialImage } from "./EditorialImage";

interface AboutGraziSectionProps {
  onZoomPhoto: (photo: StudioPhoto) => void;
}

export function AboutGraziSection({ onZoomPhoto }: AboutGraziSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="sobre-grazi"
      className="bg-[hsl(var(--background))] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{
            duration: prefersReducedMotion ? 0 : 0.55,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="mx-auto grid max-w-4xl grid-cols-1 items-center gap-10 rounded-3xl border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] p-6 shadow-sm sm:p-10 md:grid-cols-12"
        >
          {/* Compact Portrait of Grazi */}
          <div className="flex justify-center md:col-span-5">
            <div className="w-full max-w-[260px] overflow-hidden rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--surface))] p-2">
              <EditorialImage
                src={STUDIO_IMAGES.grazi.src}
                alt={STUDIO_IMAGES.grazi.alt}
                onZoom={() => onZoomPhoto(STUDIO_IMAGES.grazi)}
                className="aspect-[3/4] w-full rounded-xl"
              />
            </div>
          </div>

          {/* Warm Professional Welcome Copy */}
          <div className="space-y-5 md:col-span-7">
            <p className="text-xs font-semibold tracking-[0.14em] text-[hsl(var(--accent-text))] uppercase">
              Sobre mim
            </p>

            <h2 className="font-display text-[clamp(1.75rem,3vw,2.5rem)] leading-tight font-semibold tracking-tight text-[hsl(var(--foreground))]">
              Prazer, sou a Grazi!
            </h2>

            <p className="text-sm leading-relaxed text-[hsl(var(--foreground-muted))] sm:text-base">
              Seja bem-vindo ao {STUDIO_INFO.name}. Meu compromisso é oferecer um
              atendimento acolhedor, atencioso e cuidadoso, para que você se
              sinta confortável e à vontade em cada etapa.
            </p>

            <p className="text-sm leading-relaxed text-[hsl(var(--foreground-muted))] sm:text-base">
              Cada horário é reservado especialmente para você, com foco em
              higiene, respeito à sensibilidade da pele e bem-estar em um
              ambiente tranquilo em Ariquemes.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href={buildWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-11 items-center gap-2 rounded-full bg-[hsl(var(--accent))] px-5 py-2.5 text-xs font-semibold text-[hsl(var(--accent-ink))] transition-colors hover:bg-[hsl(var(--accent-hover))] whitespace-nowrap"
              >
                <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Conversar com a Grazi</span>
              </a>

              <a
                href={STUDIO_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-11 items-center gap-2 rounded-full border border-[hsl(var(--border-strong))] bg-[hsl(var(--background))] px-5 py-2.5 text-xs font-semibold text-[hsl(var(--foreground))] transition-colors hover:border-[hsl(var(--accent))] whitespace-nowrap"
              >
                <Instagram className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>{STUDIO_INFO.instagramHandle}</span>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
