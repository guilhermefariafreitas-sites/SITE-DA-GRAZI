import { useState } from "react";
import { Sparkles, ZoomIn } from "lucide-react";

interface EditorialImageProps {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  priority?: boolean;
  onZoom?: () => void;
}

export function EditorialImage({
  src,
  alt,
  className = "",
  imgClassName = "",
  priority = false,
  onZoom,
}: EditorialImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center gap-3 bg-[linear-gradient(135deg,hsl(var(--surface))_0%,hsl(var(--accent)/0.2)_100%)] p-6 text-center ${className}`}
      >
        <Sparkles
          className="h-6 w-6 text-[hsl(var(--accent-text))]"
          strokeWidth={1.5}
          aria-hidden="true"
        />
        <span className="font-display text-base font-semibold text-[hsl(var(--foreground))]">
          Studio de Beleza Grasi Neves
        </span>
      </div>
    );
  }

  const imageElement = (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      loading={priority ? "eager" : "lazy"}
      decoding={priority ? "sync" : "async"}
      onError={() => setHasError(true)}
      className={`h-full w-full object-cover ${imgClassName}`}
    />
  );

  if (onZoom) {
    return (
      <button
        type="button"
        onClick={onZoom}
        aria-label={`Ampliar imagem: ${alt}`}
        className={`group relative block w-full cursor-zoom-in overflow-hidden bg-[hsl(var(--surface))] text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--accent))] ${className}`}
      >
        {imageElement}
        <span className="pointer-events-none absolute right-2.5 bottom-2.5 inline-flex h-8 w-8 items-center justify-center rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--background)/0.9)] text-[hsl(var(--foreground))] opacity-80 shadow-sm transition-opacity duration-200 group-hover:opacity-100">
          <ZoomIn className="h-4 w-4" aria-hidden="true" />
        </span>
      </button>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-[hsl(var(--surface))] ${className}`}>
      {imageElement}
    </div>
  );
}
