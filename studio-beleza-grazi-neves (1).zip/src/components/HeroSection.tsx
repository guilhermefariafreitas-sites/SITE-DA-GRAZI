import { ArrowDownRight, MessageCircle } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import { buildWhatsAppUrl, STUDIO_INFO } from "../data/studio";

export function HeroSection() {
  const prefersReducedMotion = useReducedMotion();
  const whatsappHref = buildWhatsAppUrl();

  const transition = {
    duration: prefersReducedMotion ? 0 : 0.55,
    ease: [0.16, 1, 0.3, 1] as const,
  };

  return (
    <section
      id="inicio"
      className="bg-[hsl(var(--background))] pt-28 pb-16 sm:pt-32 sm:pb-20 lg:pt-36 lg:pb-24"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={transition}
          className="mx-auto max-w-3xl space-y-6 text-center"
        >
          <p className="text-xs font-semibold tracking-[0.14em] text-[hsl(var(--accent-text))] uppercase">
            {STUDIO_INFO.name}
          </p>

          <h1 className="font-display text-[clamp(2.15rem,4.4vw,3.6rem)] leading-[1.12] font-semibold tracking-tight text-[hsl(var(--foreground))] text-balance">
            {STUDIO_INFO.slogan}
          </h1>

          <p className="mx-auto max-w-xl text-base leading-relaxed text-[hsl(var(--foreground-muted))] sm:text-lg">
            Um espaço acolhedor em Ariquemes dedicado à depilação com cera,
            Banho de Lua e cuidados com a pele.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-12 items-center gap-2.5 rounded-full bg-[hsl(var(--accent))] px-7 py-3.5 text-sm font-semibold text-[hsl(var(--accent-ink))] transition-all duration-200 hover:-translate-y-0.5 hover:bg-[hsl(var(--accent-hover))] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--foreground))]"
            >
              <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>Agendar pelo WhatsApp</span>
            </a>

            <a
              href="#servicos"
              className="inline-flex min-h-12 items-center gap-1.5 rounded-full border border-[hsl(var(--border-strong))] bg-[hsl(var(--surface-elevated))] px-6 py-3.5 text-sm font-semibold text-[hsl(var(--foreground))] transition-colors duration-200 hover:border-[hsl(var(--accent))] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--accent))]"
            >
              <span>Ver serviços e valores</span>
              <ArrowDownRight className="h-4 w-4 shrink-0" aria-hidden="true" />
            </a>
          </div>

          <p className="mx-auto max-w-md border-t border-[hsl(var(--border))] pt-5 text-xs font-medium text-[hsl(var(--foreground-muted))]">
            {STUDIO_INFO.neighborhood} · {STUDIO_INFO.city} ·{" "}
            <span className="tabular-nums">{STUDIO_INFO.phoneDisplay}</span>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
