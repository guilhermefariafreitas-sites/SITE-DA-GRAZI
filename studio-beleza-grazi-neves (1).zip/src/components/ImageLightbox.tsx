import { useEffect } from "react";
import { X } from "lucide-react";
import { StudioPhoto } from "../data/studio";

interface ImageLightboxProps {
  photo: StudioPhoto | null;
  onClose: () => void;
}

export function ImageLightbox({ photo, onClose }: ImageLightboxProps) {
  useEffect(() => {
    if (!photo) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [photo, onClose]);

  if (!photo) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={photo.alt}
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[hsl(var(--foreground)/0.75)] p-4 backdrop-blur-sm sm:p-6"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-h-[90vh] w-full max-w-2xl overflow-hidden rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] p-3 shadow-2xl sm:p-4"
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Fechar ampliação da imagem"
          className="absolute top-5 right-5 z-10 inline-flex h-11 w-11 items-center justify-center rounded-full border border-[hsl(var(--border))] bg-[hsl(var(--background)/0.95)] text-[hsl(var(--foreground))] shadow-sm transition-colors hover:border-[hsl(var(--accent))] hover:bg-[hsl(var(--accent))] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(var(--accent))]"
        >
          <X className="h-5 w-5" aria-hidden="true" />
        </button>

        <div className="flex max-h-[76vh] items-center justify-center overflow-hidden rounded-xl bg-[hsl(var(--surface))]">
          <img
            src={photo.src}
            alt={photo.alt}
            referrerPolicy="no-referrer"
            className="max-h-[76vh] w-auto max-w-full object-contain"
          />
        </div>

        <p className="mt-3 px-1 text-center text-xs font-medium text-[hsl(var(--foreground-muted))] sm:text-sm">
          {photo.caption}
        </p>
      </div>
    </div>
  );
}
