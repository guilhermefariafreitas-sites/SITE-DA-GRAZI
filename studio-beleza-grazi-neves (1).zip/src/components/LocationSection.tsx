import { ArrowUpRight, MapPin } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
import { STUDIO_IMAGES, STUDIO_INFO, StudioPhoto } from "../data/studio";
import { EditorialImage } from "./EditorialImage";

interface LocationSectionProps {
  onZoomPhoto: (photo: StudioPhoto) => void;
}

export function LocationSection({ onZoomPhoto }: LocationSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="localizacao"
      className="border-t border-[hsl(var(--border))] bg-[hsl(var(--surface))] py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-[1240px] px-5 sm:px-8 lg:px-10">
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{
            duration: prefersReducedMotion ? 0 : 0.5,
            ease: [0.16, 1, 0.3, 1],
          }}
          className="grid grid-cols-1 items-center gap-10 lg:grid-cols-12"
        >
          {/* Address & Map CTA Left */}
          <div className="space-y-6 lg:col-span-6">
            <div className="space-y-3">
              <p className="text-xs font-semibold tracking-[0.14em] text-[hsl(var(--accent-text))] uppercase">
                Localização
              </p>
              <h2 className="font-display text-[clamp(1.75rem,3.2vw,2.65rem)] leading-tight font-semibold tracking-tight text-[hsl(var(--foreground))]">
                Onde Estamos
              </h2>
              <p className="text-sm leading-relaxed text-[hsl(var(--foreground-muted))] sm:text-base">
                Fácil acesso no bairro Rota do Sol em Ariquemes, com ambiente
                preparado para receber você com conforto e privacidade.
              </p>
            </div>

            <div className="rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] p-6 shadow-sm">
              <div className="flex items-start gap-3.5">
                <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[hsl(var(--accent)/0.25)] text-[hsl(var(--foreground))]">
                  <MapPin className="h-5 w-5" aria-hidden="true" />
                </span>
                <div className="space-y-2">
                  <p className="text-xs font-semibold tracking-wider text-[hsl(var(--foreground-muted))] uppercase">
                    Endereço oficial
                  </p>
                  <p className="text-sm font-medium leading-relaxed text-[hsl(var(--foreground))] sm:text-base">
                    {STUDIO_INFO.address}
                  </p>
                </div>
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-3 border-t border-[hsl(var(--border))] pt-5">
                <a
                  href={STUDIO_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 items-center gap-2 rounded-full bg-[hsl(var(--accent))] px-6 py-2.5 text-sm font-semibold text-[hsl(var(--accent-ink))] transition-colors hover:bg-[hsl(var(--accent-hover))] whitespace-nowrap"
                >
                  <MapPin className="h-4 w-4 shrink-0" aria-hidden="true" />
                  <span>Como chegar</span>
                  <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
                </a>

                <a
                  href={STUDIO_INFO.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-semibold text-[hsl(var(--accent-text))] underline-offset-4 hover:underline"
                >
                  Abrir no Google Maps
                </a>
              </div>
            </div>
          </div>

          {/* Compact Treatment Room Photos Right */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:col-span-6">
            <figure className="mx-auto w-full max-w-xs space-y-2 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] p-2.5 shadow-sm">
              <EditorialImage
                src={STUDIO_IMAGES.reception.src}
                alt={STUDIO_IMAGES.reception.alt}
                onZoom={() => onZoomPhoto(STUDIO_IMAGES.reception)}
                className="aspect-[4/3] w-full rounded-xl"
              />
              <figcaption className="text-center text-xs font-medium text-[hsl(var(--foreground-muted))]">
                {STUDIO_IMAGES.reception.caption}
              </figcaption>
            </figure>

            <figure className="mx-auto w-full max-w-xs space-y-2 rounded-2xl border border-[hsl(var(--border))] bg-[hsl(var(--surface-elevated))] p-2.5 shadow-sm">
              <EditorialImage
                src={STUDIO_IMAGES.treatmentRoom.src}
                alt={STUDIO_IMAGES.treatmentRoom.alt}
                onZoom={() => onZoomPhoto(STUDIO_IMAGES.treatmentRoom)}
                className="aspect-[4/3] w-full rounded-xl"
              />
              <figcaption className="text-center text-xs font-medium text-[hsl(var(--foreground-muted))]">
                {STUDIO_IMAGES.treatmentRoom.caption}
              </figcaption>
            </figure>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
