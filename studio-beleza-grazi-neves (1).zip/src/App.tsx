import { useState } from "react";
import { MotionConfig } from "motion/react";
import { AboutGraziSection } from "./components/AboutGraziSection";
import { BanhoDeLuaSection } from "./components/BanhoDeLuaSection";
import { BookingSection } from "./components/BookingSection";
import { ContactFooter } from "./components/ContactFooter";
import { FloatingActions } from "./components/FloatingActions";
import { HeroSection } from "./components/HeroSection";
import { ImageLightbox } from "./components/ImageLightbox";
import { LocationSection } from "./components/LocationSection";
import { Navbar } from "./components/Navbar";
import { ServicesSection } from "./components/ServicesSection";
import { StudioSpaceSection } from "./components/StudioSpaceSection";
import { TestimonialsSection } from "./components/TestimonialsSection";
import { DEPILATION_SERVICES, StudioPhoto } from "./data/studio";

export default function App() {
  const [selectedServiceId, setSelectedServiceId] = useState<string>(
    DEPILATION_SERVICES[0].id
  );
  const [zoomedPhoto, setZoomedPhoto] = useState<StudioPhoto | null>(null);

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[hsl(var(--background))] text-[hsl(var(--foreground))]">
        {/* 1. Cabeçalho com logo e menu */}
        <Navbar />

        <main>
          {/* 2. Apresentação principal */}
          <HeroSection />

          {/* 3. Prazer, sou a Grazi! */}
          <AboutGraziSection onZoomPhoto={setZoomedPhoto} />

          {/* 5. Conheça Nosso Espaço */}
          <StudioSpaceSection onZoomPhoto={setZoomedPhoto} />

          {/* 6. Nossos Serviços */}
          <ServicesSection onSelectService={setSelectedServiceId} />

          {/* 7. Banho de Lua */}
          <BanhoDeLuaSection
            onSelectService={setSelectedServiceId}
            onZoomPhoto={setZoomedPhoto}
          />

          {/* 8. Feedback das clientes */}
          <TestimonialsSection onZoomPhoto={setZoomedPhoto} />

          {/* 9. Localização e fotos do atendimento */}
          <LocationSection onZoomPhoto={setZoomedPhoto} />

          {/* 10. Agendamento Online + Contato e Rodapé */}
          <BookingSection
            selectedServiceId={selectedServiceId}
            onSelectService={setSelectedServiceId}
          />
        </main>

        <ContactFooter />
        <FloatingActions />

        <ImageLightbox
          photo={zoomedPhoto}
          onClose={() => setZoomedPhoto(null)}
        />
      </div>
    </MotionConfig>
  );
}
