import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import JSZip from 'jszip';
import path from 'path';
import {defineConfig, type Plugin} from 'vite';

const ZIP_FILENAME = 'studio-beleza-grazi-neves.zip';
const IGNORED_DIRS = new Set(['node_modules', 'dist', '.git', '.aistudio']);

function addDirToZip(zip: JSZip, rootDir: string, currentDir: string): void {
  const entries = fs.readdirSync(currentDir, {withFileTypes: true});
  for (const entry of entries) {
    if (IGNORED_DIRS.has(entry.name)) continue;
    if (entry.name.endsWith('.zip')) continue;

    const fullPath = path.join(currentDir, entry.name);
    const relPath = path.relative(rootDir, fullPath).split(path.sep).join('/');

    if (entry.isDirectory()) {
      addDirToZip(zip, rootDir, fullPath);
    } else if (entry.isFile()) {
      zip.file(relPath, fs.readFileSync(fullPath));
    }
  }
}

async function createProjectZipBuffer(rootDir: string): Promise<Buffer> {
  const zip = new JSZip();
  addDirToZip(zip, rootDir, rootDir);
  return zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: {level: 6},
  });
}

function projectZipExportPlugin(): Plugin {
  return {
    name: 'project-zip-export',
    configureServer(server) {
      server.middlewares.use(`/${ZIP_FILENAME}`, async (_req, res, next) => {
        try {
          const buffer = await createProjectZipBuffer(__dirname);
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/zip');
          res.setHeader(
            'Content-Disposition',
            `attachment; filename="${ZIP_FILENAME}"`,
          );
          res.setHeader('Cache-Control', 'no-store');
          res.end(buffer);
        } catch (err) {
          next(err);
        }
      });
    },
    async closeBundle(error?: Error): Promise<void> {
      if (error) return;
      const distDir = path.resolve(__dirname, 'dist');
      if (fs.existsSync(distDir)) {
        const buffer = await createProjectZipBuffer(__dirname);
        fs.writeFileSync(path.join(distDir, ZIP_FILENAME), buffer);
      }
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      projectZipExportPlugin(),
      // Copies src/assets into dist/ so root-relative URLs like
      // "/src/assets/images/..." (e.g. generate_image output) still resolve
      // in production builds. Do not remove.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        closeBundle(error?: Error): void {
          if (error) {
            return;
          }
          const distDir = path.resolve(__dirname, 'dist');
          const srcAssets = path.resolve(__dirname, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, {recursive: true, force: true});
          }
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
